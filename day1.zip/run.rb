require "./Movie.rb"

spartacus = {
    title: "Spartacus",
    :genre => "Action"
}

puts spartacus[:title]
puts spartacus[:genre]